﻿using System.Threading.Tasks;
using MassTransit;

using Microsoft.Extensions.Logging;
using OrderModel;

namespace MassTransitConsumer
{
    public class OrderConsumer : IConsumer<Order>
    {
        private readonly ILogger<OrderConsumer> _logger;

        public OrderConsumer(ILogger<OrderConsumer> logger)
        {
            _logger = logger;
        }

        public Task Consume(ConsumeContext<Order> context)
        {

            _logger.LogInformation($"Order processed: OrderId:{context.Message.OrderId} - OrderId:{context.Message.OrderId}");

            return Task.CompletedTask;
        }
    }

}