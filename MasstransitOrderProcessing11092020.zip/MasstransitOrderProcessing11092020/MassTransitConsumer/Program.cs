﻿using System;
using System.Threading.Tasks;
using MassTransit;
using MassTransit.Azure.ServiceBus.Core;
using MassTransitConsumer;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OrderModel;

namespace MassTransitConsumer
{
    class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = new HostBuilder()
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddMassTransit(config =>
                    {
                        config.AddConsumer<OrderConsumer>();
                       config.AddBus(ConfigureBus);
                    });

                    services.AddSingleton<IHostedService, MassTransitConsoleHostedService>();
                })
                .ConfigureLogging((hostingContext, logging) =>
                {
                    logging.SetMinimumLevel(LogLevel.Information);
                    logging.AddConsole();
                });

            

            await builder.RunConsoleAsync();
        }

        static IBusControl ConfigureBus(IServiceProvider provider)
        {
            string ConnectionString = "Endpoint=sb://rpsmtsb2020.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=/DzJpwEdIt9F44hXSfKRyoJy0NQrTZP/IbKaTOfT+xw=";

            string MasstransitOrderTopic = "mastransit-orders";

            string subscriptionName = "electronicssubscr";

            string queueName = "order-queue";

            
            var azureServiceBus = Bus.Factory.CreateUsingAzureServiceBus(busFactoryConfig =>
            {

                busFactoryConfig.Message<Order>(m => { m.SetEntityName(MasstransitOrderTopic); });

                var host = busFactoryConfig.Host(ConnectionString, hostConfig => 
                {
                    hostConfig.TransportType = TransportType.AmqpWebSockets;
                });

                // setup Azure topic consumer
                busFactoryConfig.SubscriptionEndpoint<Order>(host, subscriptionName, configurator =>
                {
                    configurator.Consumer<OrderConsumer>(provider);
                });


                // setup Azure queue consumer
                busFactoryConfig.ReceiveEndpoint(host, queueName, configurator =>
                {
                    configurator.Consumer<OrderConsumer>(provider);

                    // as this is a queue, no need to subscribe to topics, so set this to false.
                    // configurator.SubscribeMessageTopics = false;
                });
            });


            return azureServiceBus;
        }
    }
}
