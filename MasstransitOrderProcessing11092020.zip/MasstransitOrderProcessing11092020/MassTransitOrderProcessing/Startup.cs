using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MassTransit;
using OrderModel;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MassTransitOrderProcessing
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            string ConnectionString = "Endpoint=sb://rpsmtsb2020.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=/DzJpwEdIt9F44hXSfKRyoJy0NQrTZP/IbKaTOfT+xw=";

            string MasstransitOrderTopic = "mastransit-orders";


            

            var azureServiceBus = Bus.Factory.CreateUsingAzureServiceBus(busFactoryConfig =>
            {
                // specify the message Order to be sent to a specific topic
                busFactoryConfig.Message<Order>(configTopology =>
                {
                    configTopology.SetEntityName(MasstransitOrderTopic);
                  
                    
                });

                
                //busFactoryConfig.SubscriptionEndpoint(..., cfg => cfg.Rule)
                busFactoryConfig.Host(ConnectionString, hostConfig =>
                {
                    // This is optional, but you can specify the protocol to use.
                   // hostConfig.TransportType = TransportType.AmqpWebSockets;
                });



            });
            // Add MassTransit
            services.AddMassTransit(config =>
            {
                config.AddBus(provider => azureServiceBus);
            });

            services.AddSingleton<IPublishEndpoint>(azureServiceBus);
            services.AddSingleton<ISendEndpointProvider>(azureServiceBus);
            services.AddSingleton<IBus>(azureServiceBus);

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            //services.AddMassTransit(x =>
            //{
            //   x.UsingAzureServiceBus((context, cfg) =>
            //    {
            //        cfg.Host(ConnectionString);

            //        cfg.ReceiveEndpoint(MasstransitOrderTopic, e =>
            //        {
            //            // all of these are optional!!

            //            e.PrefetchCount = 100;

            //            // number of "threads" to run concurrently
            //            e.MaxConcurrentCalls = 100;

            //            // default, but shown for example
            //            e.LockDuration = TimeSpan.FromMinutes(5);

            //            // lock will be renewed up to 30 minutes
            //            e.MaxAutoRenewDuration = TimeSpan.FromMinutes(30);
            //            //set message end point
            //            cfg.Message<Order>(configTopology =>
            //            {
            //                configTopology.SetEntityName(MasstransitOrderTopic);
            //            });



            //        });
            //    });
            //});



        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
            });
          //  app.UseMvc();
        }
    }
}
