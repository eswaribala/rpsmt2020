﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MassTransit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Logging;
using OrderModel;

namespace MassTransitOrderProcessing.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly IPublishEndpoint _publishEndpoint;
        private readonly ISendEndpointProvider _sendEndpointProvider;
        private readonly Random _random;

        public IndexModel(IPublishEndpoint publishEndpoint, ISendEndpointProvider sendEndpointProvider)
        {
            _publishEndpoint = publishEndpoint;
            _sendEndpointProvider = sendEndpointProvider;

            _random = new Random();
        }

        public void OnGet()
        {

        }
        public async Task<IActionResult> OnPostPurchaseFlightAsync()
        {
            Supplier SupplierObj = new Supplier { SupplierId=new Random().Next(),SupplierName="S1"};
            Product ProductObj = new Product {ProductId=new Random().Next(),Name="P1",SupplierDetail=SupplierObj,Cost=4676 };
            IList<Product> Products = new List<Product>();
            Products.Add(ProductObj);
            Order OrderObj = new Order {OrderId=new Random().Next(),OrderAmount=24883,DOP=new DateTime(2020,1,1),ProductList= Products};
            //Message message = new Message { Label = "Electronics" };
           // message.UserProperties.Add("Category", "Electronics");
                
            //message.CorrelationId = "Kitchen";
            

            await _publishEndpoint.Publish<Order>(OrderObj);

            return Page();
        }

        
        public async Task<IActionResult> OnPostEnqueueMessageAsync()
        {
            var sendEndpoint =
                await _sendEndpointProvider.GetSendEndpoint(
                    new Uri("sb://rpsmtsb2020.servicebus.windows.net/order-queue"));


            //await sendEndpoint.Send<Order>(new Order { OrderId = 21376, OrderAmount = 24956, DOP = new DateTime(2020, 1, 1), ProductList = null });

            await sendEndpoint.Send<Order>(new { OrderId = InVar.Id }, context =>
                    context.CorrelationId = new Guid());

            // Set CorrelationId using initializer header
            await sendEndpoint.Send<Order>(new
            {
                OrderId = InVar.Id,
                __CorrelationId = InVar.Id

                // InVar.Id returns the same value within the message initializer
            });


            return Page();
        }

    }
}
