﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderModel
{
    public class Product
    {
        public long ProductId { get; set; }
        public string Name { get; set; }
        public long Cost { get; set; }

        public Supplier SupplierDetail { get; set; }
        

    }
}
