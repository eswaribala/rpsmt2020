﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderModel
{
   public class Supplier
    {
        public long SupplierId { get; set; }
        public string SupplierName { get; set; }
    }
}
