﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderModel
{
    public class Order
    {

        public long OrderId { get; set; }
        public IList<Product> ProductList { get; set; }
        public DateTime DOP { get; set; }
        public long OrderAmount { get; set; }
    }
}
