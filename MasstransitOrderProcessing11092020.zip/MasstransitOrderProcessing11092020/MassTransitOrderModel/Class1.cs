﻿using System;

namespace MassTransitOrderModel
{
    public class Class1
    {
    }
}
