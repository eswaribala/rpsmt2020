﻿# Using Serverless Azure Functions (FaaS) to write Service Bus Topic messages to NoSQL Azure Table Storage
> Intrigued by serverless architecture? Chief Technology Officer (CTO) Simon Gilbert explains how to use Microsoft Azure Functions to write Service Bus messages via the pub-sub pattern to Azure Table Storage

![Simon Gilbert CTO Tech Blog Landscape Image](https://www.simongilbert.net/content/images/2019/04/simon-gilbert-dev-cto-blog-19.png)

## Read My Accompanying Blog
- https://www.simongilbert.net/serverless-azure-functions-service-bus-table-storage/

## Read My Other Blogs
- https://www.simongilbert.net

### License
See the [LICENSE](LICENSE.md) file for license rights and limitations (MIT).
