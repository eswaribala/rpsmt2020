using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Newtonsoft.Json;
using System;
using System.Text;

namespace AzureFunctionTopic
{
    public static class ProcessOrdersTrigger
    {
        [FunctionName("ProcessOrdersTrigger")]
        [return: Table("%AzureTableStorageToWriteDataTo%", Connection = "AzureTableStorageConnectionString")]
        public static RestaurantOrderViewModel Run(
           [ServiceBusTrigger(
                "%AzureServiceBusTopicName%",
                "%AzureServiceBusSubscriptionName%",
                Connection = "AzureServiceBusPrimaryConnectionString")]
        Message message)
        {
            return FromMessage(message);
        }

        private static RestaurantOrderViewModel FromMessage(Message message)
        {
            var restaurantOrderViewModel = JsonConvert.DeserializeObject<RestaurantOrderViewModel>(
                Encoding.UTF8.GetString(message.Body));

            restaurantOrderViewModel.PartitionKey = Guid.NewGuid().ToString();
            restaurantOrderViewModel.RowKey = Guid.NewGuid().ToString();

            return restaurantOrderViewModel;
        }
    }
}
