﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace AzureFunctionTopic
{
    public class RestaurantOrderViewModel : TableEntity
    {
        public string RestaurantName { get; set; }

        public string StarterCourse { get; set; }

        public string MainCourse { get; set; }

        public string DessertCourse { get; set; }
    }
}
