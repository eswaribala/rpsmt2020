﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace OrderProducer
{
    class AzureBusConnectionHelper
    {
        public static String ConnectionString { get; set; }
        public static String QueueName { get; set; }

        public static void LoadJson()
        {

            //        IConfiguration Configuration = new ConfigurationBuilder()
            //.AddJsonFile("OrderConfig.json", optional: true, reloadOnChange: true)    
            //.Build();

            //        Console.WriteLine(Configuration.GetSection("Values").Value);

            //get the Json filepath  
            //JObject o1 = JObject.Parse(File.ReadAllText("OrderConfig.json"));

            // read JSON directly from a file
            using (StreamReader file = File.OpenText("OrderConfig.json"))
            using (JsonTextReader reader = new JsonTextReader(file))
            {
                JObject o2 = (JObject)JToken.ReadFrom(reader);
                Console.WriteLine(o2["Values"]["AzureServiceBusQueueName"].ToString());
                ConnectionString = o2["Values"]["AzureServiceBusPrimaryConnectionString"].ToString();
                QueueName= o2["Values"]["AzureServiceBusQueueName"].ToString();

            }


        }

    }
}
