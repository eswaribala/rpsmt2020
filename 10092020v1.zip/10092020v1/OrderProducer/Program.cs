﻿using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using OrderModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;

namespace OrderProducer
{
    class Program
    {
        private static IQueueClient queueClient;
       // private const string ServiceBusConnectionString = "Endpoint=sb://rpsmtsb2020.servicebus.windows.net/;SharedAccessKeyName=producer;SharedAccessKey=z/yhKqDzcbCy30LZPBgqPZ+HNBwZNeKQRKsSvW5gGFE=";
       // private const string QueueName = "order-queue";

        static void Main(string[] args)
        {
            AzureBusConnectionHelper.LoadJson();
            Console.WriteLine(AzureBusConnectionHelper.ConnectionString);

            //Console.ReadKey();

            OrderTask(args).GetAwaiter().GetResult();
        }




        public static async Task OrderTask(String[] args)
        {
            queueClient = new QueueClient(AzureBusConnectionHelper.ConnectionString, AzureBusConnectionHelper.QueueName, ReceiveMode.PeekLock);

            await SendMessagesToQueue();

            // Close the client after the ReceiveMessages method has exited. 
            await queueClient.CloseAsync();

            Console.WriteLine("Press any key to exit.");
            Console.ReadLine();

        }

        private static async Task SendMessagesToQueue()
        {
            Product product = new Product { ProductId = 2370, Name = "Laptop", Cost = 38568 };
            IList<Product> Products = new List<Product>();
            Products.Add(product);

            Order order = new Order { OrderId = 1, OrderAmount = 3468, DOP = new DateTime(2020, 1, 1), ProductList = Products };


            try
            {
                // Create a new brokered message to send to the queue 
                string messageBody = JsonConvert.SerializeObject(order);
                Message message = new Message(Encoding.UTF8.GetBytes(messageBody))
                {

                };


                message.CorrelationId = "East-Region";
                message.MessageId = new Guid().ToString();
                //message.ContentType=""
                // Write the body of the message to the console 
                Console.WriteLine($"Sending message: {Encoding.UTF8.GetString(message.Body)}");

                // Send the message to the queue 
                await queueClient.SendAsync(message);
            }
            catch (Exception exception)
            {
                Console.WriteLine($"{DateTime.Now} > Exception: {exception.Message}");
            }

            // Delay by 10 milliseconds so that the console can keep up 
            await Task.Delay(10);


            Console.WriteLine($" messages sent.");
        }
    }

    
}
