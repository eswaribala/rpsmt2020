﻿using Microsoft.Azure.ServiceBus;
using System;
using System.Threading.Tasks;

namespace OrderModel
{
    class Program
    {

        static void Main(string[] args)
        {




        }
    }

       
    
}
