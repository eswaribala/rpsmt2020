﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace OrderModel
{
    public class Product
    {
        public long ProductId { get; set; }
        public string Name { get; set; }
        public long Cost { get; set; }
        

    }
}
