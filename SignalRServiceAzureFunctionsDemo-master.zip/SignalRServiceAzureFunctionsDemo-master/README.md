# SignalRServiceAzureFunctionsDemo

Demo code for the DontCodeTired.com blog post [http://dontcodetired.com/blog/post/Using-the-Azure-SignalR-Service-Bindings-in-Azure-Functions-to-Create-Real-time-Serverless-Applications] showing how to use Azure SignalR Service with Azure Functions and client JavaScript
