﻿using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.ServiceBus.Core;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TopicReceiveMessage
{
    class Program
    {
        const string ServiceBusConnectionString="Endpoint=sb://rpsmtsb2020.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=95bMGqFoAPl+3I4Se+t7+SpYz8O7zYLisc/K349qZtA=";
        const string TopicName = "rpstopic";
       // const string SubscriptionName = "chnsubscr";
        const string allMessagesSubscriptionName = "indsubscr";
        const string sqlFilterOnlySubscriptionName = "sngsubscr";
        const string sqlFilterWithActionSubscriptionName = "ussubscr";
        const string correlationFilterSubscriptionName = "uksubscr";
        static ISubscriptionClient allMessagessubscriptionClient, sqlFilterOnlySubscriptionClient, sqlFilterWithActionSubscriptionClient, correlationFilterSubscriptionClient;
        static ITopicClient topicClient;
        public static async Task Main(string[] args)
    {
            topicClient = new TopicClient(ServiceBusConnectionString, TopicName);
            allMessagessubscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, allMessagesSubscriptionName);
            sqlFilterOnlySubscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, sqlFilterOnlySubscriptionName);
            sqlFilterWithActionSubscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, sqlFilterWithActionSubscriptionName);
            correlationFilterSubscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, correlationFilterSubscriptionName);
            // subscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, SubscriptionName);
            //            var credentials = SdkContext.AzureCredentialsFactory.FromFile(@"authpath");
            //            var azure = Azure
            //                        .Configure()
            //                        .WithLogLevel(HttpLoggingDelegatingHandler.Level.Basic)
            //                        .Authenticate(credentials)
            //                        .WithDefaultSubscription();
            //            var sbNameSpace = "service bus subscription";
            //            var resoureGroup = "resourcegroup";
            //            var topicName = "topicName"
            //var servicebus = azure.ServiceBusNamespaces.GetByResourceGroup(resoureGroup, sbNameSpace);
            //            var topic = servicebus.Topics.GetByName(topicName);
            //            var subscription = topic.Subscriptions.List();

            Console.WriteLine("======================================================");
        Console.WriteLine("Press ENTER key to exit after receiving all the messages.");
        Console.WriteLine("======================================================");
            





            // Receive messages from 'allMessagesSubscriptionName'. Should receive all 9 messages 
            await ReceiveMessagesAsync(allMessagesSubscriptionName);

            // Receive messages from 'sqlFilterOnlySubscriptionName'. Should receive all messages with Color = 'Red' i.e 3 messages
            await ReceiveMessagesAsync(sqlFilterOnlySubscriptionName);

            // Receive messages from 'sqlFilterWithActionSubscriptionClient'. Should receive all messages with Color = 'Blue'
            // i.e 3 messages AND all messages should have color set to 'BlueProcessed'
            await ReceiveMessagesAsync(sqlFilterWithActionSubscriptionName);

            // Receive messages from 'correlationFilterSubscriptionName'. Should receive all messages  with Color = 'Red' and CorrelationId = "important"
            // i.e 1 message
            await ReceiveMessagesAsync(correlationFilterSubscriptionName);


            Console.ReadKey();

            await allMessagessubscriptionClient.CloseAsync();
            await sqlFilterOnlySubscriptionClient.CloseAsync();
            await sqlFilterWithActionSubscriptionClient.CloseAsync();
            await correlationFilterSubscriptionClient.CloseAsync();
            await topicClient.CloseAsync();
        }

        static async Task ReceiveMessagesAsync(string subscriptionName)
        {
            string subscriptionPath = EntityNameHelper.FormatSubscriptionPath(TopicName, subscriptionName);
            IMessageReceiver subscriptionReceiver = new MessageReceiver(ServiceBusConnectionString, subscriptionPath, ReceiveMode.ReceiveAndDelete);

            Console.WriteLine($"==========================================================================");
            Console.WriteLine($"{DateTime.Now} :: Receiving Messages From Subscription: {subscriptionName}");
            int receivedMessageCount = 0;
            while (true)
            {
                var receivedMessage = await subscriptionReceiver.ReceiveAsync(TimeSpan.FromSeconds(5));
                if (receivedMessage != null)
                {
                    object colorProperty;
                    receivedMessage.UserProperties.TryGetValue("Color", out colorProperty);
                    Console.WriteLine($"Color Property = {colorProperty}, CorrelationId = {receivedMessage.CorrelationId ?? receivedMessage.CorrelationId}");
                    receivedMessageCount++;
                }
                else
                {
                    break;
                }
            }

            Console.WriteLine($"{DateTime.Now} :: Received '{receivedMessageCount}' Messages From Subscription: {subscriptionName}");
            Console.WriteLine($"==========================================================================");
            await subscriptionReceiver.CloseAsync();
        }


       
    }



}
