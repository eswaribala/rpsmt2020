﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderPersistenceTrigger
{
   public class Supplier
    {
        public long SupplierId { get; set; }
        public string SupplierName { get; set; }
    }
}
