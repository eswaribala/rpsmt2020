﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace OrderPersistenceTrigger
{
    public class Order:TableEntity
    {

        public long OrderId { get; set; }
        public IList<Product> ProductList { get; set; }
        public DateTime DOP { get; set; }
        public long OrderAmount { get; set; }
    }
}
