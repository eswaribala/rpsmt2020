using System;
using System.Text;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

//using OrderModel;

namespace OrderPersistenceTrigger
{
   
    
    public static class OrderPersistenceTrigger
    {
        [FunctionName("OrderPersistenceTrigger")]
        [return: Table("%AzureTableStorageToWriteDataTo%", Connection = "AzureTableStorageConnectionString")]

        public static Order Run([ServiceBusTrigger( "%AzureServiceBusQueueName%",
                             Connection = "AzureServiceBusPrimaryConnectionString")]
        Message message,ILogger log)
        {
            log.LogInformation($"C# ServiceBus queue trigger function processed message: {message}");
           return FromMessage(message);
        
        }
        private static Order  FromMessage(Message message)
        {
            var OrderViewModel = JsonConvert.DeserializeObject<Order>(
                Encoding.UTF8.GetString(message.Body));
            Console.WriteLine(OrderViewModel.OrderId);
            OrderViewModel.PartitionKey = Guid.NewGuid().ToString();
            OrderViewModel.RowKey = Guid.NewGuid().ToString();

            return OrderViewModel;
           


        }
    }
}
