﻿using System;
using System.Collections.Generic;
//using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace OrderModelStandard
{
    public class Product
    {
        public long ProductId { get; set; }
        public string Name { get; set; }
        public long Cost { get; set; }

        public Supplier SupplierDetail { get; set; }
        

    }
}
